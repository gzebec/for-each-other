﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace BPUIO_OneForEachOther.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "cv_authentication_schemes",
                columns: table => new
                {
                    AuthenticationSchemeId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(nullable: true),
                    Status = table.Column<string>(nullable: true),
                    Created = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    Updated = table.Column<DateTime>(nullable: false),
                    UpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cv_authentication_schemes", x => x.AuthenticationSchemeId);
                });

            migrationBuilder.CreateTable(
                name: "cv_countries",
                columns: table => new
                {
                    CountryId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Code = table.Column<string>(nullable: true),
                    Name = table.Column<string>(nullable: true),
                    Language = table.Column<string>(nullable: true),
                    IconUrl = table.Column<string>(nullable: true),
                    Status = table.Column<string>(nullable: true),
                    Created = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    Updated = table.Column<DateTime>(nullable: false),
                    UpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cv_countries", x => x.CountryId);
                });

            migrationBuilder.CreateTable(
                name: "cv_roles",
                columns: table => new
                {
                    RoleId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(nullable: true),
                    Description = table.Column<string>(nullable: true),
                    Status = table.Column<string>(nullable: true),
                    Created = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    Updated = table.Column<DateTime>(nullable: false),
                    UpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cv_roles", x => x.RoleId);
                });

            migrationBuilder.CreateTable(
                name: "cv_cities",
                columns: table => new
                {
                    CityId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CountryId = table.Column<int>(nullable: false),
                    Code = table.Column<string>(nullable: true),
                    Name = table.Column<string>(nullable: true),
                    Status = table.Column<string>(nullable: true),
                    Created = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    Updated = table.Column<DateTime>(nullable: false),
                    UpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cv_cities", x => x.CityId);
                    table.ForeignKey(
                        name: "FK_cv_cities_cv_countries_CountryId",
                        column: x => x.CountryId,
                        principalTable: "cv_countries",
                        principalColumn: "CountryId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "cv_users",
                columns: table => new
                {
                    UserId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CountryId = table.Column<int>(nullable: false),
                    AuthenticationSchemeId = table.Column<int>(nullable: false),
                    Username = table.Column<string>(nullable: true),
                    Password = table.Column<string>(nullable: true),
                    FirstName = table.Column<string>(nullable: true),
                    LastName = table.Column<string>(nullable: true),
                    Email = table.Column<string>(nullable: true),
                    Address = table.Column<string>(nullable: true),
                    Phone = table.Column<string>(nullable: true),
                    Lat = table.Column<decimal>(nullable: false),
                    Lng = table.Column<decimal>(nullable: false),
                    GdprConsent = table.Column<string>(nullable: true),
                    GdprConsentDate = table.Column<DateTime>(nullable: false),
                    Status = table.Column<string>(nullable: true),
                    Created = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    Updated = table.Column<DateTime>(nullable: false),
                    UpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cv_users", x => x.UserId);
                    table.ForeignKey(
                        name: "FK_cv_users_cv_authentication_schemes_AuthenticationSchemeId",
                        column: x => x.AuthenticationSchemeId,
                        principalTable: "cv_authentication_schemes",
                        principalColumn: "AuthenticationSchemeId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_cv_users_cv_countries_CountryId",
                        column: x => x.CountryId,
                        principalTable: "cv_countries",
                        principalColumn: "CountryId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "cv_boroughs",
                columns: table => new
                {
                    BoroughId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CityId = table.Column<int>(nullable: false),
                    Code = table.Column<string>(nullable: true),
                    Name = table.Column<string>(nullable: true),
                    Status = table.Column<string>(nullable: true),
                    Created = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    Updated = table.Column<DateTime>(nullable: false),
                    UpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cv_boroughs", x => x.BoroughId);
                    table.ForeignKey(
                        name: "FK_cv_boroughs_cv_cities_CityId",
                        column: x => x.CityId,
                        principalTable: "cv_cities",
                        principalColumn: "CityId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "cv_user_notifications",
                columns: table => new
                {
                    UserNotificationId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<int>(nullable: false),
                    Subject = table.Column<string>(nullable: true),
                    Text = table.Column<string>(nullable: true),
                    Status = table.Column<string>(nullable: true),
                    Created = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    Updated = table.Column<DateTime>(nullable: false),
                    UpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cv_user_notifications", x => x.UserNotificationId);
                    table.ForeignKey(
                        name: "FK_cv_user_notifications_cv_users_UserId",
                        column: x => x.UserId,
                        principalTable: "cv_users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "cv_user_roles",
                columns: table => new
                {
                    UserRoleId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RoleId = table.Column<int>(nullable: false),
                    UserId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    Status = table.Column<string>(nullable: true),
                    Created = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    Updated = table.Column<DateTime>(nullable: false),
                    UpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cv_user_roles", x => x.UserRoleId);
                    table.ForeignKey(
                        name: "FK_cv_user_roles_cv_roles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "cv_roles",
                        principalColumn: "RoleId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_cv_user_roles_cv_users_UserId",
                        column: x => x.UserId,
                        principalTable: "cv_users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "cv_orders",
                columns: table => new
                {
                    OrderId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<int>(nullable: false),
                    BoroughId = table.Column<int>(nullable: false),
                    FirstName = table.Column<string>(nullable: true),
                    LastName = table.Column<string>(nullable: true),
                    Email = table.Column<string>(nullable: true),
                    Address = table.Column<string>(nullable: true),
                    Phone = table.Column<string>(nullable: true),
                    DeliveryDate = table.Column<DateTime>(nullable: false),
                    PaymentType = table.Column<string>(nullable: true),
                    Note = table.Column<string>(nullable: true),
                    Lat = table.Column<decimal>(nullable: false),
                    Lng = table.Column<decimal>(nullable: false),
                    GdprConsent = table.Column<string>(nullable: true),
                    GdprConsentDate = table.Column<DateTime>(nullable: false),
                    Status = table.Column<string>(nullable: true),
                    Created = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    Updated = table.Column<DateTime>(nullable: false),
                    UpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cv_orders", x => x.OrderId);
                    table.ForeignKey(
                        name: "FK_cv_orders_cv_boroughs_BoroughId",
                        column: x => x.BoroughId,
                        principalTable: "cv_boroughs",
                        principalColumn: "BoroughId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_cv_orders_cv_users_UserId",
                        column: x => x.UserId,
                        principalTable: "cv_users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "cv_user_boroughs",
                columns: table => new
                {
                    UserBoroughId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<int>(nullable: false),
                    BoroughId = table.Column<int>(nullable: false),
                    Status = table.Column<string>(nullable: true),
                    Created = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    Updated = table.Column<DateTime>(nullable: false),
                    UpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cv_user_boroughs", x => x.UserBoroughId);
                    table.ForeignKey(
                        name: "FK_cv_user_boroughs_cv_boroughs_BoroughId",
                        column: x => x.BoroughId,
                        principalTable: "cv_boroughs",
                        principalColumn: "BoroughId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_cv_user_boroughs_cv_users_UserId",
                        column: x => x.UserId,
                        principalTable: "cv_users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "cv_order_details",
                columns: table => new
                {
                    OrderDetailId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OrderId = table.Column<int>(nullable: false),
                    Item = table.Column<string>(nullable: true),
                    Quantity = table.Column<decimal>(nullable: false),
                    Status = table.Column<string>(nullable: true),
                    Created = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    Updated = table.Column<DateTime>(nullable: false),
                    UpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cv_order_details", x => x.OrderDetailId);
                    table.ForeignKey(
                        name: "FK_cv_order_details_cv_orders_OrderId",
                        column: x => x.OrderId,
                        principalTable: "cv_orders",
                        principalColumn: "OrderId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_cv_boroughs_CityId",
                table: "cv_boroughs",
                column: "CityId");

            migrationBuilder.CreateIndex(
                name: "IX_cv_cities_CountryId",
                table: "cv_cities",
                column: "CountryId");

            migrationBuilder.CreateIndex(
                name: "IX_cv_order_details_OrderId",
                table: "cv_order_details",
                column: "OrderId");

            migrationBuilder.CreateIndex(
                name: "IX_cv_orders_BoroughId",
                table: "cv_orders",
                column: "BoroughId");

            migrationBuilder.CreateIndex(
                name: "IX_cv_orders_UserId",
                table: "cv_orders",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_cv_user_boroughs_BoroughId",
                table: "cv_user_boroughs",
                column: "BoroughId");

            migrationBuilder.CreateIndex(
                name: "IX_cv_user_boroughs_UserId",
                table: "cv_user_boroughs",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_cv_user_notifications_UserId",
                table: "cv_user_notifications",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_cv_user_roles_RoleId",
                table: "cv_user_roles",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "IX_cv_user_roles_UserId",
                table: "cv_user_roles",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_cv_users_AuthenticationSchemeId",
                table: "cv_users",
                column: "AuthenticationSchemeId");

            migrationBuilder.CreateIndex(
                name: "IX_cv_users_CountryId",
                table: "cv_users",
                column: "CountryId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "cv_order_details");

            migrationBuilder.DropTable(
                name: "cv_user_boroughs");

            migrationBuilder.DropTable(
                name: "cv_user_notifications");

            migrationBuilder.DropTable(
                name: "cv_user_roles");

            migrationBuilder.DropTable(
                name: "cv_orders");

            migrationBuilder.DropTable(
                name: "cv_roles");

            migrationBuilder.DropTable(
                name: "cv_boroughs");

            migrationBuilder.DropTable(
                name: "cv_users");

            migrationBuilder.DropTable(
                name: "cv_cities");

            migrationBuilder.DropTable(
                name: "cv_authentication_schemes");

            migrationBuilder.DropTable(
                name: "cv_countries");
        }
    }
}
