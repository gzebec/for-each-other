﻿using BPUIO_OneForEachOther.Models;
using System;
using System.Linq;

namespace BPUIO_OneForEachOther.Data
{
    public static class DbInitializer
    {
        public static void Initialize(ApplicationContext context)
        {
            context.Database.EnsureCreated();

            // Look for any roles.
            if (context.Roles.Any())
            {
                return;   // DB has been seeded
            }

            var roles = new Role[]
            {
                new Role{RoleId=1,Description="Administrator role",Status="A",Created=DateTime.Now,CreatedBy="Admin",Updated=DateTime.Now,UpdatedBy="Admin"},
                new Role{RoleId=2,Description="Contributer role",Status="A",Created=DateTime.Now,CreatedBy="Admin",Updated=DateTime.Now,UpdatedBy="Admin"}
            };
            foreach (Role r in roles)
            {
                context.Roles.Add(r);
            }
            context.SaveChanges();

            var schemes = new AuthenticationScheme[]
{
                new AuthenticationScheme{AuthenticationSchemeId=1,Name="Standard authentication scheme",Status="A",Created=DateTime.Now,CreatedBy="Admin",Updated=DateTime.Now,UpdatedBy="Admin"},
};
            foreach (Role r in roles)
            {
                context.Roles.Add(r);
            }
            context.SaveChanges();

            var countries = new Country[]
            {
                new Country{CountryId=1,Code="hr",Name="Croatia",Language="hr",Status="A",Created=DateTime.Now,CreatedBy="Admin",Updated=DateTime.Now,UpdatedBy="Admin"}
            };
            foreach (Country c in countries)
            {
                context.Countries.Add(c);
            }
            context.SaveChanges();

            var users = new User[]
            {
                new User{UserId=1,Username="admin",Password="admin11",FirstName="Admin",LastName="User",Email="gzebec@gmail.com",Status="A",Created=DateTime.Now,CreatedBy="Admin",Updated=DateTime.Now,UpdatedBy="Admin",CountryId=1, AuthenticationSchemeId=1}
            };
            foreach (User u in users)
            {
                context.Users.Add(u);
            }
            context.SaveChanges();

            var userRoles = new UserRole[]
{
                new UserRole{UserId=1,RoleId=1,Status="A",Created=DateTime.Now,CreatedBy="Admin",Updated=DateTime.Now,UpdatedBy="Admin"}
};
            foreach (User u in users)
            {
                context.Users.Add(u);
            }
            context.SaveChanges();
        }
    }
}