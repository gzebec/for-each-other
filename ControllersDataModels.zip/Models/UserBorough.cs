﻿using System;
using System.Collections.Generic;

namespace BPUIO_OneForEachOther.Models
{
    public class UserBorough
    {
        public int UserBoroughId { get; set; }
        public int UserId { get; set; }
        public int BoroughId { get; set; }
        public string Status { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime Updated { get; set; }
        public string UpdatedBy { get; set; }

        public User User { get; set; }
        public Borough Borough { get; set; }
    }
}